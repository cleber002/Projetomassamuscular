
function toggleChapter(element) {
  const content = element.querySelector('.chapter-content');
  if (content.style.display === 'block') {
    content.style.display = 'none';
  } else {
    content.style.display = 'block';
  }
}
